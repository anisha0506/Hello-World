package exercise.jobs;

import exercise.jobs.dao.JobStoreDao;
import exercise.jobs.model.Applicant;
import exercise.jobs.repository.JobApplicationRepository;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Part B unit tests
 */
public class MaxSubmissionsUnitTests {

    @Before
    public void clean(){
        JobApplicationRepository repository = new JobApplicationRepository(new JobStoreDao());
        repository.cleanup();
    }
    @Test
    public void maxSubmissionsDay() {
        Applicant a1 = Applicant.builder().firstName("a").lastName("b").jobId(5).build();
        Applicant a2 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();
        Applicant a3 = Applicant.builder().firstName("e").lastName("f").jobId(5).build();
        Applicant a4 = Applicant.builder().firstName("g").lastName("h").jobId(5).build();


        Submissions submissions = new Submissions(new JobApplicationRepository(new JobStoreDao()));
        submissions.applyForJob(a1);
        submissions.applyForJob(a2);
        submissions.applyForJob(a3);
        submissions.applyForJob(a4);

        assertEquals(4, submissions.maxSubmissionsDay(5));
    }

}