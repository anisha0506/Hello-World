package exercise.jobs;

import exercise.jobs.dao.JobStoreDao;
import exercise.jobs.model.Applicant;
import exercise.jobs.repository.JobApplicationRepository;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class WithdrawJobApplicationUnitTests {
    @Before
    public void clean(){
        JobApplicationRepository repository = new JobApplicationRepository(new JobStoreDao());
        repository.cleanup();
    }
    @Test
    public void withdrawJobApplication() {
        Applicant a1 = Applicant.builder().firstName("a").lastName("b").jobId(5).build();
        Applicant a2 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();
        Applicant a3 = Applicant.builder().firstName("e").lastName("f").jobId(5).build();
        Applicant a4 = Applicant.builder().firstName("g").lastName("h").jobId(5).build();

        Submissions submissions = new Submissions(new JobApplicationRepository(new JobStoreDao()));
        submissions.applyForJob(a1);
        submissions.applyForJob(a2);
        submissions.applyForJob(a3);
        submissions.applyForJob(a4);
        //Withdraw 2 applicants
        submissions.withdrawApplication(a1);
        submissions.withdrawApplication(a3);
        assertEquals(2, submissions.getJobApplcants(5).size());
    }
}
