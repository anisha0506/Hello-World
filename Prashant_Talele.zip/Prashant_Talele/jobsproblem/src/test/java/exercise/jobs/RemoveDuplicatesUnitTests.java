package exercise.jobs;

import exercise.jobs.dao.JobStoreDao;
import exercise.jobs.model.Applicant;
import exercise.jobs.repository.JobApplicationRepository;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Part A unit tests
 */
public class RemoveDuplicatesUnitTests {

    @Before
    public void clean(){
        JobApplicationRepository repository = new JobApplicationRepository(new JobStoreDao());
        repository.cleanup();
    }

    @Test
    public void oneDup() {
        Applicant p1 = Applicant.builder().firstName("a").lastName("b").jobId(5).build();
        Applicant p2 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();
        Applicant p3 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();

        Submissions submissions = new Submissions(new JobApplicationRepository(new JobStoreDao()));
        submissions.applyForJob(p1);
        submissions.applyForJob(p2);
        submissions.applyForJob(p3);
        checkAssert(submissions, Arrays.asList(p1, p2));
    }

    @Test
    public void oneDup_diffOrder() {

        Applicant p1 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();
        Applicant p2 = Applicant.builder().firstName("a").lastName("b").jobId(5).build();
        Applicant p3 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();


        Submissions submissions = new Submissions(new JobApplicationRepository(new JobStoreDao()));
        submissions.applyForJob(p1);
        submissions.applyForJob(p2);
        submissions.applyForJob(p3);

        checkAssert(submissions, Arrays.asList(p1, p2));
    }

    @Test
    public void oneDup_priorToDeletion() {
        Applicant p1 = Applicant.builder().firstName("a").lastName("b").jobId(5).build();
        Applicant p2 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();
        Applicant p3 = Applicant.builder().firstName("c").lastName("d").jobId(5).build();

        Submissions submissions = new Submissions(new JobApplicationRepository(new JobStoreDao()));
        submissions.applyForJob(p1);
        submissions.applyForJob(p2);
        submissions.applyForJob(p3);

        checkAssert(submissions, Arrays.asList(p1, p2, p3), false);
    }

    private void checkAssert(Submissions submissions, List<Applicant> expected) {
        checkAssert(submissions, expected, true);
    }

    private void checkAssert(Submissions submissions, List<Applicant> expected, boolean removeDuplicates) {
        if (removeDuplicates) {
            submissions.removeDuplicateSubmissions();
        }
        List<Applicant> actual = submissions.getJobApplcants(5);
        assertEquals(expected.size(), actual.size());
    }

}