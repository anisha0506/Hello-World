package exercise.jobs.model;


import lombok.*;

import java.util.Date;

/**
 *
 * The job applicant and his/her submission
 *
 */
@Getter
@Setter
@Builder
@ToString
public class Applicant {

    private String firstName;
    private String lastName;

    private int jobId;
    private Date applicationDate;
    private Date withdrawnDate;

    /**
     * Overridden equals to compare Job Applicants by name.
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Applicant)) return false;
        Applicant applicant = (Applicant) o;
        return getJobId() == applicant.getJobId() && getFirstName().equalsIgnoreCase(applicant.getFirstName()) && getLastName().equalsIgnoreCase(applicant.getLastName());
    }
}
