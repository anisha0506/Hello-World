package exercise.jobs;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@Builder
public class MaxApplicantResultVO {
    private int count;
    private Date appliedOn;
}
