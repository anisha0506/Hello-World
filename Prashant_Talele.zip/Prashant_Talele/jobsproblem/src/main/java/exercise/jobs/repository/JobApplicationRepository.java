package exercise.jobs.repository;

import exercise.jobs.model.Applicant;
import exercise.jobs.MaxApplicantResultVO;
import exercise.jobs.dao.JobStoreDao;

import java.util.List;

/**
 * Repository class for abstracting persistence
 */
public class JobApplicationRepository {

    private final JobStoreDao jobStoreDao;

    public JobApplicationRepository(JobStoreDao jobStoreDao) {
        this.jobStoreDao = jobStoreDao;
    }

    public void store(Applicant applicant) {
        jobStoreDao.create(applicant);
    }

    public List<Applicant> getApplicants(int jobId) {
        return jobStoreDao.read(jobId);
    }

    public boolean withdrawApplication(Applicant applicant) {
        return jobStoreDao.withdraw(applicant);
    }

    /**
     * Delete all duplicate applications for all Jobs
     * @return
     */
    public boolean deleteDuplicatteApplications() {
        return jobStoreDao.cleanDuplicates();
    }

    /**
     * Get Maximum active applicants by Date
     * @param jobId
     * @return
     */
    public MaxApplicantResultVO[] maxActiveApplicantsByDate(int jobId) {
        return jobStoreDao.maxActiveApplicantByDate(jobId);
    }

    public int maxActiveApplicants(int jobId) {
        return jobStoreDao.getMaxApplications(jobId);
    }

    public void cleanup() {
        jobStoreDao.cleanup();
    }
}
