package exercise.jobs;


import exercise.jobs.model.Applicant;

import java.util.List;

public interface SubmissionService{
    /**
     * This operation will be used to enroll to Job
     * @param applicant
     */
    public void applyForJob(Applicant applicant);

    /**
     * Get all active Job applicants by JobId
     * Defaulting it to one job for scoping
     * @param jobId
     * @return
     */
    public List<Applicant> getJobApplcants(int jobId);

    /**
     * Remove all duplicate Job submissions
     */
    public boolean removeDuplicateSubmissions();

    /**
     * Get highest amount of active submissions until current day for
     * provided JobId
     * @return
     */
    public int maxSubmissionsDay(int jobId);

    /**
     * Withdraw Job application
     * @param applicant
     * @return
     */
    public boolean withdrawApplication(Applicant applicant);
}
