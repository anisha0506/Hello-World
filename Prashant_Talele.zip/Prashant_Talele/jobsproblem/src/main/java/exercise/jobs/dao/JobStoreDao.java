package exercise.jobs.dao;

import exercise.jobs.model.Applicant;
import exercise.jobs.MaxApplicantResultVO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JobStoreDAO will handle all Database operations.
 */
public class JobStoreDao {
    private final String INSERT_JOB_APPLICATION = "insert into job_applications(firstname, lastname, jobid, withdrawn_on) values (?, ?,?,NULL)";
    private final String WITHDRAW_JOB_APPLICATION = "update job_applications set withdrawn_on=current_timestamp() where jobid=? and firstname=? and lastname=?";
    private final String GET_ACTIVE_JOB_APPLICANTS = "select * from job_applications where jobid=? and  withdrawn_on IS NULL";
    private final String DELETE_DUPLICATE_JOB_APPLICANTS = "DELETE FROM job_applications WHERE ID NOT IN" +
            " (SELECT MIN(ID) AS MinRecordID FROM job_applications GROUP BY firstname, lastname,  jobid) AND WITHdrawn_on IS NULL";
    private final String GET_MAX_ACTIVE_APPLICANTS_BY_DATE = "select cast(applied_on as date) as appliedOn, count(*) as count from job_applications where Jobid=? and withdrawn_on IS NULL group by cast(applied_on as date)";
    private final String GET_MAX_ACTIVE_APPLICANTS_FOR_JOB = "Select Max(count) as maxCount from (select cast(applied_on as date) as appliedOn, count(*) as count from job_applications where Jobid=? and withdrawn_on IS NULL group by cast(applied_on as date))";

    private final String url = "jdbc:h2:tcp://localhost:9092/~/tmp/h2dbs/jobdb";

    private Connection getConnection(){
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, "sa", "s$cret");
        }catch (SQLException ex){
            System.out.println(ex);
        }
        return connection;
    }
    public int getMaxApplications(int jobId){
        Connection connection = null;
        int count = 0;
        try {
            connection = getConnection();

            PreparedStatement statement = connection.prepareStatement(GET_MAX_ACTIVE_APPLICANTS_FOR_JOB);
            statement.setInt(1, jobId);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
               count = resultSet.getInt("maxCount");
            }

        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                System.out.println(ex);
            }
        }
        return count;
    }

    public MaxApplicantResultVO[] maxActiveApplicantByDate(int jobId){
        Connection connection = null;
        MaxApplicantResultVO[] resultVo =  new MaxApplicantResultVO[1];
        try {
            connection = getConnection();

            PreparedStatement statement = connection.prepareStatement(GET_MAX_ACTIVE_APPLICANTS_BY_DATE);
            statement.setInt(1, jobId);
            ResultSet resultSet = statement.executeQuery();
            int rowCount = 0;
            if(resultSet!=null){
                if (resultSet.last()) {//make cursor to point to the last row in the ResultSet object
                    rowCount = resultSet.getRow();
                    resultSet.beforeFirst(); //make cursor to point to the front of the ResultSet object, just before the first row.
                }
            }
            resultVo = new MaxApplicantResultVO[rowCount];
            int i = 0;
            while(resultSet.next() && i<rowCount){
              resultVo[i] =  MaxApplicantResultVO.builder()
                        .appliedOn(resultSet.getDate("appliedOn"))
                        .count(resultSet.getInt("count"))
                        .build();
              i++;
            }

        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                System.out.println(ex);
            }
        }
        return resultVo;
    }
    public boolean create(Applicant applicant){
        Connection connection = null;
        int insertedRecordCount =-1;
        try {
             connection = getConnection();

            PreparedStatement statement = connection.prepareStatement(INSERT_JOB_APPLICATION);
            statement.setString(1, applicant.getFirstName());
            statement.setString(2, applicant.getLastName());
            statement.setInt(3, applicant.getJobId());
            insertedRecordCount = statement.executeUpdate();
        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                    System.out.println(ex);
            }
        }
        return insertedRecordCount >0;
    }

    public List<Applicant> read(int jobId){
        Connection connection = null;
        List<Applicant> applicants = new ArrayList<>();
        try {
            connection = getConnection();

            PreparedStatement statement = connection.prepareStatement(GET_ACTIVE_JOB_APPLICANTS);
            statement.setInt(1, jobId);
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()){
                applicants.add(Applicant.builder()
                        .firstName(resultSet.getString("FIRSTNAME"))
                        .lastName(resultSet.getString("LASTNAME"))
                        .jobId(resultSet.getInt("JOBID"))
                        .applicationDate(resultSet.getTimestamp("APPLIED_ON"))
                        .withdrawnDate(resultSet.getTimestamp("WITHDRAWN_ON"))
                        .build());
            }

        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                System.out.println(ex);
            }
        }

       return applicants;
    }

    /**
     * Delete the duplicated record leaving first application
     * @return
     */
    public boolean cleanDuplicates(){
        Connection connection = null;
        int updatedRecord =-1;
        try {
            connection = getConnection();

            PreparedStatement statement = connection.prepareStatement(DELETE_DUPLICATE_JOB_APPLICANTS);
            updatedRecord = statement.executeUpdate();

        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                System.out.println(ex);
            }
        }

        return updatedRecord>0;
    }

    /**
     * Delete the duplicated record leaving first application
     * @return
     */
    public boolean withdraw(Applicant applicant){
        Connection connection = null;
        int updatedRecord =-1;
        try {
            connection = getConnection();

            PreparedStatement statement = connection.prepareStatement(WITHDRAW_JOB_APPLICATION);
            statement.setInt(1, applicant.getJobId());
            statement.setString(2, applicant.getFirstName());
            statement.setString(3, applicant.getLastName());
            updatedRecord = statement.executeUpdate();

        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                System.out.println(ex);
            }
        }

        return updatedRecord>0;
    }

    public void cleanup(){
        Connection connection = null;
        try {
            connection = getConnection();

            PreparedStatement statement = connection.prepareStatement("truncate table job_applications");
           int updatedRecord = statement.executeUpdate();

        }catch (SQLException ex){
            System.out.println(ex);
        }finally {
            try {
                if (connection != null)
                    connection.close();
            }catch (SQLException ex){
                System.out.println(ex);
            }
        }
    }

}
