package exercise.jobs;

import exercise.jobs.model.Applicant;
import exercise.jobs.repository.JobApplicationRepository;

import java.util.List;

/**
 * Log of all job submissions
 */
public class Submissions implements SubmissionService {

    private JobApplicationRepository repository;

    public Submissions(JobApplicationRepository repository) {
        this.repository = repository;
    }

    /**
     * This operation will be used to enroll to Job
     *
     * @param applicant
     */
    public void applyForJob(Applicant applicant) {
        repository.store(applicant);
    }

    /**
     * Get all active Job applicants by JobId
     * Defaulting it to one job for scoping
     *
     * @param jobId
     * @return
     */
    public List<Applicant> getJobApplcants(int jobId) {
        return repository.getApplicants(jobId);
    }

    /**
     * Remove all duplicate Job submissions
     */
    public boolean removeDuplicateSubmissions() {
        return repository.deleteDuplicatteApplications();
    }

    /**
     * Remove all duplicate Job submissions
     */
    public boolean withdrawApplication(Applicant applicant) {
        return repository.withdrawApplication(applicant);
    }

    /**
     * Get highest amount of active submissions until current day for
     * provided JobId
     *
     * @return
     */
    public int maxSubmissionsDay(int jobId) {
        return repository.maxActiveApplicants(jobId);
    }


}

